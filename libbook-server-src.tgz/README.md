# LibBookServer (Java)

REST API для Android-приложения LibBook.

- **Java 17**, **NanoHTTPD**, **SQLite**, **BCrypt**
- Порт по умолчанию: **3000**
- База: `data.db` в рабочей папке

## Сборка

```bash
cd LibBookServer
mvn package
```

JAR: `target/libbook-server.jar`

## Запуск локально

```bash
java -jar target/libbook-server.jar
# или
mvn exec:java -Dexec.mainClass=com.libbook.server.Main
```

Проверка: http://localhost:3000/health и http://localhost:3000/books

## VPS (Timeweb)

1. Скопировать на сервер папку `LibBookServer` (без `target/`).
2. На сервере: `apt install -y openjdk-17-jre-headless maven` (или только JRE + готовый JAR с ПК).
3. `mvn package` → `java -jar target/libbook-server.jar`
4. Остановить старый процесс на порту 3000, если занят: `fuser -k 3000/tcp`
5. systemd (пример):

```ini
[Unit]
Description=LibBook API
After=network.target

[Service]
WorkingDirectory=/opt/libbook/LibBookServer
ExecStart=/usr/bin/java -jar /opt/libbook/LibBookServer/target/libbook-server.jar
Restart=on-failure
Environment=PORT=3000

[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload
systemctl enable libbook
systemctl start libbook
```

## Переменные окружения

| Переменная | Описание |
|------------|----------|
| `PORT` | Порт (по умолчанию 3000) |
| `DB_PATH` | Путь к SQLite (по умолчанию `./data.db`) |

## Пароли

Новые пароли хранятся как **BCrypt**. Старые записи в plain text из Node по-прежнему проверяются.
