package com.libbook.server;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

final class Database implements AutoCloseable {

    private final Connection conn;

    Database(Path dbPath) throws SQLException {
        conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath.toAbsolutePath());
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA journal_mode=WAL");
        }
        initSchema();
    }

    private void initSchema() throws SQLException {
        exec("""
                CREATE TABLE IF NOT EXISTS users (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  email TEXT UNIQUE,
                  name TEXT,
                  password TEXT,
                  icon TEXT
                );
                """);
        exec("""
                CREATE TABLE IF NOT EXISTS books (
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  name TEXT,
                  description TEXT,
                  icon TEXT,
                  tags TEXT,
                  text TEXT,
                  uploaded_by_user_id INTEGER,
                  book_password TEXT
                );
                """);
        exec("""
                CREATE TABLE IF NOT EXISTS book_ratings (
                  user_id INTEGER NOT NULL,
                  book_id INTEGER NOT NULL,
                  rating INTEGER NOT NULL,
                  PRIMARY KEY (user_id, book_id)
                );
                """);
        exec("""
                CREATE TABLE IF NOT EXISTS user_bookmarks (
                  user_id INTEGER NOT NULL,
                  book_id INTEGER NOT NULL,
                  last_opened_at INTEGER,
                  PRIMARY KEY (user_id, book_id)
                );
                """);
        ensureColumn("books", "tags", "TEXT");
        ensureColumn("books", "text", "TEXT");
        ensureColumn("books", "uploaded_by_user_id", "INTEGER");
        ensureColumn("books", "book_password", "TEXT");
    }

    private void ensureColumn(String table, String column, String type) throws SQLException {
        boolean found = false;
        try (PreparedStatement ps = conn.prepareStatement("PRAGMA table_info(" + table + ")");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                if (column.equals(rs.getString("name"))) {
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            exec("ALTER TABLE " + table + " ADD COLUMN " + column + " " + type);
        }
    }

    private void exec(String sql) throws SQLException {
        try (Statement st = conn.createStatement()) {
            st.execute(sql);
        }
    }

    Optional<JSONObject> findUserById(long id) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, email, name, icon FROM users WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                return Optional.of(rowUser(rs));
            }
        }
    }

    Optional<JSONObject> findUserByEmail(String email) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, email, name, icon FROM users WHERE email = ?")) {
            ps.setString(1, email.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                return Optional.of(rowUser(rs));
            }
        }
    }

    Optional<JSONObject> findUserByName(String name) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, email, name, icon FROM users WHERE name IS NOT NULL AND lower(trim(name)) = lower(trim(?))")) {
            ps.setString(1, name.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                return Optional.of(rowUser(rs));
            }
        }
    }

    Optional<String> findUserPassword(long id) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("SELECT password FROM users WHERE id = ?")) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                return Optional.ofNullable(rs.getString("password"));
            }
        }
    }

    long insertUser(String email, String name, String passwordHash) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO users (email, name, password) VALUES (?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, email.trim());
            ps.setString(2, name != null && !name.isBlank() ? name.trim() : null);
            ps.setString(3, passwordHash);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getLong(1);
                }
            }
        }
        throw new SQLException("no user id");
    }

    boolean isNameTakenByOther(String name, long excludeUserId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id FROM users WHERE name IS NOT NULL AND lower(trim(name)) = lower(trim(?)) AND id <> ?")) {
            ps.setString(1, name.trim());
            ps.setLong(2, excludeUserId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    void updateUserPassword(long id, String passwordHash) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("UPDATE users SET password = ? WHERE id = ?")) {
            ps.setString(1, passwordHash);
            ps.setLong(2, id);
            ps.executeUpdate();
        }
    }

    void updateUserName(long id, String name) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("UPDATE users SET name = ? WHERE id = ?")) {
            ps.setString(1, name.trim());
            ps.setLong(2, id);
            ps.executeUpdate();
        }
    }

    void updateUserEmail(long id, String email) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("UPDATE users SET email = ? WHERE id = ?")) {
            ps.setString(1, email.trim());
            ps.setLong(2, id);
            ps.executeUpdate();
        }
    }

    void updateUserIcon(long id, String icon) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("UPDATE users SET icon = ? WHERE id = ?")) {
            ps.setString(1, icon);
            ps.setLong(2, id);
            ps.executeUpdate();
        }
    }

    void deleteUser(long id) throws SQLException {
        conn.setAutoCommit(false);
        try {
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM book_ratings WHERE user_id = ?")) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM user_bookmarks WHERE user_id = ?")) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM books WHERE uploaded_by_user_id = ?")) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM users WHERE id = ?")) {
                ps.setLong(1, id);
                ps.executeUpdate();
            }
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    JSONArray listBooksWithRatings() throws SQLException {
        String sql = """
                SELECT b.id, b.name, b.description, b.icon, b.tags, b.text,
                       AVG(r.rating) AS avg_rating,
                       COUNT(r.rating) AS ratings_count
                FROM books b
                LEFT JOIN book_ratings r ON r.book_id = b.id
                GROUP BY b.id
                ORDER BY b.id
                """;
        JSONArray out = new JSONArray();
        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.put(rowBookWithStats(rs, null));
            }
        }
        return out;
    }

    JSONArray listPopularBooks(int limit) throws SQLException {
        String sql = """
                SELECT b.id, b.name, b.description, b.icon, b.tags, b.text,
                       AVG(r.rating) AS avg_rating,
                       COUNT(r.rating) AS ratings_count
                FROM books b
                LEFT JOIN book_ratings r ON r.book_id = b.id
                GROUP BY b.id
                ORDER BY avg_rating DESC, ratings_count DESC, b.id DESC
                LIMIT ?
                """;
        JSONArray out = new JSONArray();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.put(rowBookWithStats(rs, null));
                }
            }
        }
        return out;
    }

    Optional<JSONObject> findBook(long bookId, Long userId) throws SQLException {
        String sql = """
                SELECT b.id, b.name, b.description, b.icon, b.tags, b.text,
                       AVG(r.rating) AS avg_rating,
                       COUNT(r.rating) AS ratings_count
                FROM books b
                LEFT JOIN book_ratings r ON r.book_id = b.id
                WHERE b.id = ?
                GROUP BY b.id
                """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                Integer myRating = null;
                if (userId != null && userId > 0) {
                    myRating = findUserBookRating(userId, bookId).orElse(null);
                }
                return Optional.of(rowBookWithStats(rs, myRating));
            }
        }
    }

    private Optional<Integer> findUserBookRating(long userId, long bookId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT rating FROM book_ratings WHERE user_id = ? AND book_id = ?")) {
            ps.setLong(1, userId);
            ps.setLong(2, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                return Optional.of(rs.getInt("rating"));
            }
        }
    }

    long insertBook(String name, String description, String icon, String tagsJson, String text, long uploadedBy)
            throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO books (name, description, icon, tags, text, uploaded_by_user_id) VALUES (?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, description);
            ps.setString(3, icon);
            ps.setString(4, tagsJson);
            ps.setString(5, text);
            ps.setLong(6, uploadedBy);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    return keys.getLong(1);
                }
            }
        }
        throw new SQLException("no book id");
    }

    void upsertRating(long userId, long bookId, int rating) throws SQLException {
        int r = Math.max(1, Math.min(10, rating));
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO book_ratings (user_id, book_id, rating) VALUES (?, ?, ?) "
                        + "ON CONFLICT(user_id, book_id) DO UPDATE SET rating = excluded.rating")) {
            ps.setLong(1, userId);
            ps.setLong(2, bookId);
            ps.setInt(3, r);
            ps.executeUpdate();
        }
    }

    int countUploadedBooks(long userId) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) AS c FROM books WHERE uploaded_by_user_id = ?")) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt("c");
            }
        }
    }

    JSONArray listUploadedBooks(long userId) throws SQLException {
        JSONArray out = new JSONArray();
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id, name, description, icon, tags, text FROM books WHERE uploaded_by_user_id = ? ORDER BY id")) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.put(HttpUtil.bookJson(
                            rs.getLong("id"),
                            rs.getString("name"),
                            rs.getString("description"),
                            rs.getString("icon"),
                            rs.getString("tags"),
                            rs.getString("text"),
                            null,
                            null,
                            null
                    ));
                }
            }
        }
        return out;
    }

    int deleteBooksBatch(long userId, List<Long> bookIds) throws SQLException {
        if (bookIds.isEmpty()) {
            return 0;
        }
        deleteRatingsAndBookmarksForBooks(bookIds);
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < bookIds.size(); i++) {
            if (i > 0) {
                placeholders.append(",");
            }
            placeholders.append("?");
        }
        String sql = "DELETE FROM books WHERE uploaded_by_user_id = ? AND id IN (" + placeholders + ")";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            int idx = 2;
            for (Long id : bookIds) {
                ps.setLong(idx++, id);
            }
            return ps.executeUpdate();
        }
    }

    int deleteUploadedBookByName(long userId, String name) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id FROM books WHERE uploaded_by_user_id = ? AND name = ?")) {
            ps.setLong(1, userId);
            ps.setString(2, name);
            List<Long> ids = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    ids.add(rs.getLong("id"));
                }
            }
            if (ids.isEmpty()) {
                return 0;
            }
            deleteRatingsAndBookmarksForBooks(ids);
            try (PreparedStatement del = conn.prepareStatement(
                    "DELETE FROM books WHERE uploaded_by_user_id = ? AND name = ?")) {
                del.setLong(1, userId);
                del.setString(2, name);
                return del.executeUpdate();
            }
        }
    }

    private void deleteRatingsAndBookmarksForBooks(List<Long> bookIds) throws SQLException {
        if (bookIds.isEmpty()) {
            return;
        }
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < bookIds.size(); i++) {
            if (i > 0) {
                placeholders.append(",");
            }
            placeholders.append("?");
        }
        String in = placeholders.toString();
        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM book_ratings WHERE book_id IN (" + in + ")")) {
            int idx = 1;
            for (Long id : bookIds) {
                ps.setLong(idx++, id);
            }
            ps.executeUpdate();
        }
        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM user_bookmarks WHERE book_id IN (" + in + ")")) {
            int idx = 1;
            for (Long id : bookIds) {
                ps.setLong(idx++, id);
            }
            ps.executeUpdate();
        }
    }

    JSONArray listBookmarks(long userId) throws SQLException {
        String sql = """
                SELECT b.id AS book_id, b.name, b.icon, b.text, ub.last_opened_at
                FROM user_bookmarks ub
                JOIN books b ON b.id = ub.book_id
                WHERE ub.user_id = ?
                ORDER BY ub.last_opened_at DESC, b.id DESC
                """;
        JSONArray bookmarks = new JSONArray();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    JSONObject item = new JSONObject();
                    item.put("bookId", rs.getLong("book_id"));
                    item.put("name", rs.getString("name"));
                    HttpUtil.putIcon(item, rs.getString("icon"));
                    String text = rs.getString("text");
                    item.put("text", text != null ? text : JSONObject.NULL);
                    long opened = rs.getLong("last_opened_at");
                    if (!rs.wasNull() && opened > 0) {
                        item.put("lastOpenedAt", opened);
                    }
                    bookmarks.put(item);
                }
            }
        }
        return bookmarks;
    }

    void upsertBookmark(long userId, long bookId, Long lastOpenedAt) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO user_bookmarks (user_id, book_id, last_opened_at) VALUES (?, ?, ?) "
                        + "ON CONFLICT(user_id, book_id) DO UPDATE SET last_opened_at = COALESCE(excluded.last_opened_at, user_bookmarks.last_opened_at)")) {
            ps.setLong(1, userId);
            ps.setLong(2, bookId);
            if (lastOpenedAt != null && lastOpenedAt > 0) {
                ps.setLong(3, lastOpenedAt);
            } else {
                ps.setNull(3, java.sql.Types.INTEGER);
            }
            ps.executeUpdate();
        }
    }

    void deleteBookmarks(long userId, List<Long> bookIds) throws SQLException {
        if (bookIds.isEmpty()) {
            return;
        }
        StringBuilder placeholders = new StringBuilder();
        for (int i = 0; i < bookIds.size(); i++) {
            if (i > 0) {
                placeholders.append(",");
            }
            placeholders.append("?");
        }
        String sql = "DELETE FROM user_bookmarks WHERE user_id = ? AND book_id IN (" + placeholders + ")";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            int idx = 2;
            for (Long id : bookIds) {
                ps.setLong(idx++, id);
            }
            ps.executeUpdate();
        }
    }

    void syncBookmarks(long userId, JSONArray items) throws SQLException {
        conn.setAutoCommit(false);
        try {
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) {
                    continue;
                }
                long bookId = item.optLong("bookId", -1);
                if (bookId <= 0) {
                    continue;
                }
                Long lastOpened = null;
                if (item.has("lastOpenedAt") && !item.isNull("lastOpenedAt")) {
                    lastOpened = item.optLong("lastOpenedAt");
                }
                upsertBookmark(userId, bookId, lastOpened);
            }
            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    private JSONObject rowUser(ResultSet rs) throws SQLException {
        return HttpUtil.userJson(
                rs.getLong("id"),
                rs.getString("email"),
                rs.getString("name"),
                rs.getString("icon")
        );
    }

    private JSONObject rowBookWithStats(ResultSet rs, Integer myRating) throws SQLException {
        double avg = rs.getDouble("avg_rating");
        if (rs.wasNull()) {
            avg = Double.NaN;
        }
        int count = rs.getInt("ratings_count");
        Double avgBox = Double.isNaN(avg) ? null : avg;
        return HttpUtil.bookJson(
                rs.getLong("id"),
                rs.getString("name"),
                rs.getString("description"),
                rs.getString("icon"),
                rs.getString("tags"),
                rs.getString("text"),
                avgBox,
                count,
                myRating
        );
    }

    @Override
    public void close() throws SQLException {
        conn.close();
    }
}
