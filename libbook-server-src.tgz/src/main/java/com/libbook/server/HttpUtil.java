package com.libbook.server;

import fi.iki.elonen.NanoHTTPD;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class HttpUtil {

    private HttpUtil() {
    }

    static NanoHTTPD.Response okJson(Object json) {
        return json(200, json);
    }

    static NanoHTTPD.Response json(int status, Object json) {
        String body;
        if (json instanceof JSONObject obj) {
            body = obj.toString();
        } else if (json instanceof JSONArray arr) {
            body = arr.toString();
        } else {
            body = String.valueOf(json);
        }
        NanoHTTPD.Response response = NanoHTTPD.newFixedLengthResponse(
                NanoHTTPD.Response.Status.lookup(status),
                "application/json; charset=utf-8",
                body
        );
        addCors(response);
        return response;
    }

    static NanoHTTPD.Response error(int status, String code) {
        return json(status, new JSONObject().put("error", code));
    }

    static NanoHTTPD.Response noContent() {
        NanoHTTPD.Response response = NanoHTTPD.newFixedLengthResponse(
                NanoHTTPD.Response.Status.NO_CONTENT, "text/plain", ""
        );
        addCors(response);
        return response;
    }

    static NanoHTTPD.Response corsPreflight() {
        NanoHTTPD.Response response = NanoHTTPD.newFixedLengthResponse(
                NanoHTTPD.Response.Status.NO_CONTENT, "text/plain", ""
        );
        addCors(response);
        return response;
    }

    static void addCors(NanoHTTPD.Response response) {
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.addHeader("Access-Control-Allow-Headers", "Content-Type");
    }

    static String readBody(NanoHTTPD.IHTTPSession session) throws Exception {
        Map<String, String> files = new HashMap<>();
        session.parseBody(files);
        String raw = files.get("postData");
        if (raw != null) {
            return raw;
        }
        InputStream in = session.getInputStream();
        if (in == null) {
            return "";
        }
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int n;
        while ((n = in.read(chunk)) > 0) {
            buf.write(chunk, 0, n);
        }
        return buf.toString(StandardCharsets.UTF_8);
    }

    static JSONObject readJson(NanoHTTPD.IHTTPSession session) throws Exception {
        String body = readBody(session);
        if (body == null || body.isBlank()) {
            return new JSONObject();
        }
        return new JSONObject(body);
    }

    static Map<String, String> queryParams(String uri) {
        Map<String, String> out = new HashMap<>();
        int q = uri.indexOf('?');
        if (q < 0) {
            return out;
        }
        String qs = uri.substring(q + 1);
        for (String part : qs.split("&")) {
            int eq = part.indexOf('=');
            if (eq > 0) {
                out.put(urlDecode(part.substring(0, eq)), urlDecode(part.substring(eq + 1)));
            } else if (!part.isEmpty()) {
                out.put(urlDecode(part), "");
            }
        }
        return out;
    }

    static String pathOnly(String uri) {
        int q = uri.indexOf('?');
        String p = q >= 0 ? uri.substring(0, q) : uri;
        if (p.endsWith("/") && p.length() > 1) {
            p = p.substring(0, p.length() - 1);
        }
        return p;
    }

    private static String urlDecode(String s) {
        return java.net.URLDecoder.decode(s, StandardCharsets.UTF_8);
    }

    static JSONArray tagsToJson(String tagsJson) {
        if (tagsJson == null || tagsJson.isBlank()) {
            return new JSONArray();
        }
        try {
            return new JSONArray(tagsJson);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static String tagsFromJson(org.json.JSONArray tags) {
        if (tags == null) {
            return "[]";
        }
        return tags.toString();
    }

    static JSONObject bookJson(
            long id,
            String name,
            String description,
            String icon,
            String tagsJson,
            String text,
            Double avgRating,
            Integer ratingsCount,
            Integer myRating
    ) {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name != null ? name : JSONObject.NULL);
        o.put("description", description != null ? description : JSONObject.NULL);
        putIcon(o, icon);
        o.put("tags", tagsToJson(tagsJson));
        o.put("text", text != null ? text : JSONObject.NULL);
        if (avgRating != null && !avgRating.isNaN()) {
            o.put("avgRating", avgRating);
        }
        if (ratingsCount != null) {
            o.put("ratingsCount", ratingsCount);
        }
        if (myRating != null && myRating >= 1) {
            o.put("myRating", myRating);
        }
        return o;
    }

    static JSONObject userJson(long id, String email, String name, String icon) {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("email", email != null ? email : JSONObject.NULL);
        o.put("name", name != null ? name : JSONObject.NULL);
        putIcon(o, icon);
        return o;
    }

    static void putIcon(JSONObject o, String icon) {
        if (icon == null || icon.isBlank()) {
            o.put("icon", JSONObject.NULL);
            o.put("iconBase64", JSONObject.NULL);
            return;
        }
        o.put("icon", icon);
        o.put("iconBase64", icon);
    }

    static long parseLong(String s, long def) {
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static int parseInt(String s, int def) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static List<Long> longArray(org.json.JSONArray arr) {
        java.util.ArrayList<Long> out = new java.util.ArrayList<>();
        if (arr == null) {
            return out;
        }
        for (int i = 0; i < arr.length(); i++) {
            long v = arr.optLong(i, -1);
            if (v > 0) {
                out.add(v);
            }
        }
        return out;
    }
}
